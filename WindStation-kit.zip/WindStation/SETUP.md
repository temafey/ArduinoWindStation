# SETUP — развернуть проект Wind Station на новом ноутбуке (Windows 10/11)

Этот файл — инструкция для **Claude Code на ноутбуке, куда переехала плата**.
Он ставит инструменты, находит подключённый ESP32 и настраивает прошивку так же,
как на основном ПК. Проходить строго по порядку, шаги 1–6.

Всё, что нужно, лежит в этой же папке — интернет требуется только для скачивания
Claude Code, arduino-cli и ядра ESP32.

---

## 0. Установка Claude Code (делает человек, один раз)

Открыть **PowerShell** (обычный, не от админа) и выполнить:

```powershell
irm https://claude.ai/install.ps1 | iex
```

Закрыть и открыть PowerShell заново (обновится PATH), затем:

```powershell
cd <путь к этой папке>
claude
```

При первом запуске Claude Code попросит войти в аккаунт Claude — вход через браузер.
Дальше первым сообщением сказать:

> Прочитай SETUP.md и выполни шаги 1–6.

---

## 1. Проверка окружения

```powershell
powershell -ExecutionPolicy Bypass -File tools\setup-windows.ps1 -CheckOnly
```

Скрипт печатает, что уже стоит и чего не хватает: winget, arduino-cli, ядро
`esp32:esp32`, Node.js (нужен только для правки дашборда), COM-порты.

---

## 2. Драйвер USB-Serial

ESP32 DevKit V1 общается с ПК через мост USB↔UART. На нашей плате это **CP2102**
(написано на чипе рядом с AMS1117), но встречаются CH340C и CH9102X — драйвер
зависит от чипа. Windows 11 обычно ставит CP2102 сам.

Определить, что реально висит на USB:

```powershell
powershell -ExecutionPolicy Bypass -File tools\find-esp32.ps1
```

Скрипт читает VID/PID устройств и говорит, какой драйвер нужен:

| VID & PID | Чип | Драйвер |
|---|---|---|
| `VID_10C4 & PID_EA60` | CP2102 | Silicon Labs CP210x — обычно уже есть в Windows 11 |
| `VID_1A86 & PID_55D4` | CH9102X | WCH CH343SER |
| `VID_1A86 & PID_7523` | CH340C | WCH CH341SER — https://www.wch-ic.com/downloads/CH341SER_EXE.html |

Признаки проблемы:
- устройство в «Диспетчер устройств → Другие устройства» с жёлтым треугольником → драйвера нет;
- **ничего не появляется при втыкании кабеля** → чаще всего кабель зарядный, без линий данных. Взять другой кабель, прежде чем ставить драйверы.

После установки драйвера — переткнуть кабель и повторить `find-esp32.ps1`,
должен появиться `COMx`.

---

## 3. Установка arduino-cli и ядра ESP32

```powershell
powershell -ExecutionPolicy Bypass -File tools\setup-windows.ps1
```

Что делает:
1. `winget install ArduinoSA.CLI` (если winget нет — качает официальный zip в `%LOCALAPPDATA%\ArduinoCLI`);
2. `arduino-cli config init` + добавляет URL пакета Espressif;
3. `arduino-cli core install esp32:esp32` — ~200 МБ, идёт долго;
4. печатает путь к `esptool.exe` и `espota.exe` из ядра — они нужны для прошивки.

Arduino IDE **не нужна** — весь цикл идёт через arduino-cli.
Дополнительных библиотек тоже нет: WiFi, WiFiMulti, Preferences, WebServer,
ESPmDNS, ArduinoOTA, Ticker входят в ядро ESP32.

---

## 4. Сборка прошивки

```powershell
powershell -ExecutionPolicy Bypass -File tools\build.ps1
```

Это `arduino-cli compile --fqbn esp32:esp32:esp32 --export-binaries esp32_wind_station`.
Успех — строка `Sketch uses ... bytes (9x%) of program storage`. Занятость флеша
около 90% — это норма для текущей версии, не ошибка.

> Дашборд уже собран и вшит в `esp32_wind_station/web_content.h` — для прошивки
> платы Node.js и `npm install` **не нужны**. Они нужны только если менять
> внешний вид дашборда, см. шаг 6.

---

## 5. Прошивка платы по USB

```powershell
powershell -ExecutionPolicy Bypass -File tools\flash-usb.ps1
```

Скрипт сам находит COM-порт (если он один) и заливает через `arduino-cli upload`.

**Если сорвалось с `Wrong boot mode detected (0x13)` или `Write timeout`** — плата
не вошла в режим загрузки сама. Тогда ручной режим:

```powershell
powershell -ExecutionPolicy Bypass -File tools\flash-usb.ps1 -Manual
```

и по подсказке скрипта на плате:
1. зажать **BOOT** (она же IO0);
2. коротко нажать и отпустить **EN** (Reset);
3. держать **BOOT**, пока в консоли не пойдёт `Writing at 0x...`, затем отпустить.

`-Manual` зовёт `esptool.exe` с `--before no_reset` — без этого esptool сам дёргает
DTR/RTS и отменяет ручной вход в режим загрузки (а на нашей макетке автосброс
дополнительно ломает конденсатор C1 1000 мкФ на питании).

### Проверка после прошивки

```powershell
arduino-cli monitor -p COM<номер> -c baudrate=115200
```

Нажать **EN** на плате. Ожидаемо:

```
rst:0x1 (POWERON_RESET),boot:0x13 (SPI_FAST_FLASH_BOOT)
...                          ← кракозябры ROM-загрузчика (74880 baud) — норма
=== Wind Station ===
WiFi OK
IP: 192.168.1.xxx
mDNS: http://windstation.local
OTA ready
HTTP: 80
V=0.0 m/s  D=0°  G=0.0  Bat=0.00V (0%)  RSSI=-30
```

Сплошные кракозябры на всём выводе = не тот baud rate, должно быть **115200**.

### WiFi на новом месте

Сохранённых сетей нашей квартиры на новом месте не будет. Станция поднимет
**открытую точку доступа `WindStation-Setup`**:

1. подключиться к ней с телефона/ноутбука;
2. открыть `http://192.168.4.1` — это тот же дашборд, вшитый в прошивку;
3. ⚙ Настройки → «WiFi-сети станции» → SSID + пароль → «+ Добавить»;
4. через ~30 с станция сама подключится к домашней сети и выключит свою точку.

ESP32 работает **только в 2.4 ГГц**. Если роутер раздаёт `MyWifi` и `MyWifi_5G` —
выбирать без `_5G`.

После этого дашборд открывается по IP станции с любого устройства сети
(`windstation.local` на Windows часто не резолвится — использовать IP).

---

## 6. Дальнейшие прошивки — по WiFi (OTA), USB больше не нужен

```powershell
powershell -ExecutionPolicy Bypass -File tools\flash-ota.ps1 -Ip 192.168.1.xxx
```

Пароль OTA: спросить у автора прошивки (в комплекте его нет), порт платы 3232, локальный порт 45678.

Три вещи, которые ломают OTA (проверено на основном ПК):
- **Брандмауэр.** espota поднимает слушающий порт 45678, к которому подключается
  плата. Нужно правило: TCP inbound, порт 45678. Без него `No response from device`
  ещё до передачи данных. Скрипт предложит создать правило (требует прав админа).
- **Флаки.** Заливка может сорваться на финальном ACK при отличном сигнале.
  Рецепт: перезагрузить плату по питанию и повторить, до 3 попыток.
- **Как понять, что залилось.** Не по выводу espota — финальное
  `Unexpected response from device: '1024'` это косметика. Успех = **сброс `uptime`**
  в `http://<ip>/api/data`.

### Если менялся дашборд (`wind-dashboard.jsx`)

Полный цикл — три шага, пропуск любого означает, что плата отдаёт старый UI:

```powershell
cd wind-ui; npm install; npm run build; cd ..
python esp32_wind_station\gen_web_header.py
powershell -ExecutionPolicy Bypass -File tools\build.ps1
powershell -ExecutionPolicy Bypass -File tools\flash-ota.ps1 -Ip 192.168.1.xxx
```

Нужен Node.js (`winget install OpenJS.NodeJS.LTS`) и Python
(`winget install Python.Python.3.13`). Известная засада на основном ПК:
`lightningcss-win32-x64-msvc` не встаёт через npm из-за OneDrive — если папка
проекта на новом ноуте **не** в OneDrive, проблемы быть не должно.

---

## Частые проблемы

| Симптом | Причина | Решение |
|---|---|---|
| Нет COM-порта при втыкании | Кабель без линий данных / нет драйвера | Сменить кабель, затем `tools\find-esp32.ps1` |
| `Wrong boot mode (0x13)` | Плата не в режиме загрузки | `flash-usb.ps1 -Manual`, BOOT → EN → держать BOOT |
| Кракозябры в мониторе | Не тот baud rate | 115200 |
| `No response from device` при OTA | Брандмауэр режет входящие на 45678 | Создать правило (скрипт предложит) |
| OTA оборвалась на 99% | Известная флакость | Перезагрузить плату по питанию, повторить |
| `speed: 4.3` без датчика | Плавающий ADC-пин GPIO34 | Норма, пропадёт после подключения датчика |
| `windstation.local` не открывается | mDNS на Windows нестабилен | Использовать IP станции |

Схема, распиновка и вся электрика — в `wind-station-assembly.md`.
Правила работы с кодом (три файла меняются вместе) — в `CLAUDE.md`.
