﻿# setup-windows.ps1 — ставит arduino-cli и ядро ESP32, проверяет окружение.
# Запуск:  powershell -ExecutionPolicy Bypass -File tools\setup-windows.ps1
#          powershell -ExecutionPolicy Bypass -File tools\setup-windows.ps1 -CheckOnly

param(
    [switch]$CheckOnly   # только диагностика, ничего не устанавливать
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot '_common.ps1')

$esp32Url = 'https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json'
$cliZip   = 'https://downloads.arduino.cc/arduino-cli/arduino-cli_latest_Windows_64bit.zip'

function Show-Check {
    param([string]$Name, [bool]$Ok, [string]$Detail)
    $mark = if ($Ok) { '[ есть ]' } else { '[ НЕТ  ]' }
    $color = if ($Ok) { 'Green' } else { 'Yellow' }
    Write-Host ("  {0} {1,-16} {2}" -f $mark, $Name, $Detail) -ForegroundColor $color
}

Write-Host ''
Write-Host '=== Проверка окружения ===' -ForegroundColor Cyan

$winget = (Get-Command winget.exe -ErrorAction SilentlyContinue)
Show-Check 'winget'      ([bool]$winget) $(if ($winget) { $winget.Source } else { 'не найден — arduino-cli поставим из zip' })

$cli = Get-ArduinoCli
Show-Check 'arduino-cli'  ([bool]$cli)   $(if ($cli) { $cli } else { 'будет установлен' })

$core = Get-Esp32CorePath
Show-Check 'ядро esp32'   ([bool]$core)  $(if ($core) { $core } else { 'будет установлено (~200 МБ)' })

$node = (Get-Command node.exe -ErrorAction SilentlyContinue)
Show-Check 'node.js'      ([bool]$node)  $(if ($node) { (& node --version) } else { 'нужен ТОЛЬКО для правки дашборда — для прошивки не требуется' })

$py = (Get-Command py.exe -ErrorAction SilentlyContinue)
if (-not $py) { $py = (Get-Command python.exe -ErrorAction SilentlyContinue) }
Show-Check 'python'       ([bool]$py)    $(if ($py) { $py.Source } else { 'нужен ТОЛЬКО для gen_web_header.py — для прошивки не требуется' })

Write-Host ''
Write-Host '=== USB / COM ===' -ForegroundColor Cyan
& (Join-Path $PSScriptRoot 'find-esp32.ps1') | Out-Host

if ($CheckOnly) {
    Write-Host ''
    Write-Host 'Режим -CheckOnly: ничего не устанавливалось.' -ForegroundColor Cyan
    exit 0
}

# --- 1. arduino-cli -------------------------------------------------------
if (-not $cli) {
    Write-Host ''
    Write-Host '=== Установка arduino-cli ===' -ForegroundColor Cyan
    if ($winget) {
        winget install --id ArduinoSA.CLI --accept-source-agreements --accept-package-agreements --silent
        # winget кладёт shim в %LOCALAPPDATA%\Microsoft\WinGet\Links — он появится в PATH после перезапуска оболочки
        $env:Path = "$env:LOCALAPPDATA\Microsoft\WinGet\Links;$env:Path"
    } else {
        $dest = "$env:LOCALAPPDATA\ArduinoCLI"
        New-Item -ItemType Directory -Force $dest | Out-Null
        $tmp = Join-Path $env:TEMP 'arduino-cli.zip'
        Write-Host "Качаю $cliZip ..."
        Invoke-WebRequest -Uri $cliZip -OutFile $tmp
        Expand-Archive -Path $tmp -DestinationPath $dest -Force
        Write-Host "Распаковано в $dest"
        $env:Path = "$dest;$env:Path"
    }
    $cli = Get-ArduinoCli
    if (-not $cli) {
        Write-Host 'arduino-cli установить не удалось — поставить вручную и повторить.' -ForegroundColor Red
        exit 1
    }
    Write-Host "arduino-cli: $cli" -ForegroundColor Green
}

& $cli version

# --- 2. Конфиг и индекс Espressif ----------------------------------------
Write-Host ''
Write-Host '=== Конфиг arduino-cli ===' -ForegroundColor Cyan
$cfg = & $cli config dump 2>$null
if ($LASTEXITCODE -ne 0 -or -not $cfg) { & $cli config init | Out-Host }

$cfg = (& $cli config dump) -join "`n"
if ($cfg -notmatch [regex]::Escape($esp32Url)) {
    & $cli config add board_manager.additional_urls $esp32Url
    Write-Host 'URL пакета Espressif добавлен.' -ForegroundColor Green
} else {
    Write-Host 'URL пакета Espressif уже прописан.' -ForegroundColor Green
}

& $cli core update-index | Out-Host

# --- 3. Ядро esp32 --------------------------------------------------------
if (-not (Get-Esp32CorePath)) {
    Write-Host ''
    Write-Host '=== Установка ядра esp32:esp32 (~200 МБ, это надолго) ===' -ForegroundColor Cyan
    & $cli core install esp32:esp32 | Out-Host
} else {
    Write-Host 'Ядро esp32 уже установлено.' -ForegroundColor Green
}

$core = Get-Esp32CorePath
if (-not $core) {
    Write-Host 'Ядро esp32 не установилось — см. вывод выше.' -ForegroundColor Red
    exit 1
}

# --- 4. Итог --------------------------------------------------------------
Write-Host ''
Write-Host '=== Готово ===' -ForegroundColor Cyan
Write-Host ("  arduino-cli : {0}" -f (Get-ArduinoCli))
Write-Host ("  ядро esp32  : {0}" -f $core)
Write-Host ("  esptool.exe : {0}" -f (Get-CoreTool 'esptool.exe'))
Write-Host ("  espota.exe  : {0}" -f (Get-CoreTool 'espota.exe'))
Write-Host ''
Write-Host 'Дальше — шаг 4 SETUP.md:'
Write-Host '  powershell -ExecutionPolicy Bypass -File tools\build.ps1'
