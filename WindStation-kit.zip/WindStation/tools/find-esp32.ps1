﻿# find-esp32.ps1 — ищет подключённый ESP32 DevKit и говорит, какой драйвер нужен.
# Запуск:  powershell -ExecutionPolicy Bypass -File tools\find-esp32.ps1
# Выход:   0 — плата найдена как COM-порт, 1 — не найдена (см. подсказки в выводе)

$ErrorActionPreference = 'Stop'

# VID/PID мостов USB-UART, встречающихся на ESP32 DevKit V1
$known = @(
    @{ Vid = '10C4'; Pid = 'EA60'; Chip = 'CP2102';  Driver = 'Silicon Labs CP210x (Windows 11 обычно ставит сам): https://www.silabs.com/developer-tools/usb-to-uart-bridge-vcp-drivers' },
    @{ Vid = '10C4'; Pid = 'EA70'; Chip = 'CP2105';  Driver = 'Silicon Labs CP210x: https://www.silabs.com/developer-tools/usb-to-uart-bridge-vcp-drivers' },
    @{ Vid = '1A86'; Pid = '55D4'; Chip = 'CH9102X'; Driver = 'WCH CH343SER: https://www.wch-ic.com/downloads/CH343SER_EXE.html' },
    @{ Vid = '1A86'; Pid = '7523'; Chip = 'CH340C';  Driver = 'WCH CH341SER: https://www.wch-ic.com/downloads/CH341SER_EXE.html' },
    @{ Vid = '303A'; Pid = '1001'; Chip = 'USB-JTAG/Serial (встроен в ESP32-S2/S3/C3)'; Driver = 'драйвер не нужен' }
)

Write-Host ''
Write-Host '=== Поиск ESP32 на USB ===' -ForegroundColor Cyan

$devices = @()
try {
    $devices = Get-PnpDevice -PresentOnly -ErrorAction Stop |
        Where-Object { $_.InstanceId -like 'USB\VID_*' }
} catch {
    $devices = Get-CimInstance Win32_PnPEntity |
        Where-Object { $_.PNPDeviceID -like 'USB\VID_*' } |
        ForEach-Object {
            [pscustomobject]@{ InstanceId = $_.PNPDeviceID; FriendlyName = $_.Name; Status = $_.Status; Class = $_.PNPClass }
        }
}

$hits = @()
foreach ($d in $devices) {
    if ($d.InstanceId -match 'VID_([0-9A-Fa-f]{4})&PID_([0-9A-Fa-f]{4})') {
        $vid = $Matches[1].ToUpper(); $pidHex = $Matches[2].ToUpper()
        $match = $known | Where-Object { $_.Vid -eq $vid -and $_.Pid -eq $pidHex }
        if ($match) {
            $hits += [pscustomobject]@{
                Chip   = $match.Chip
                Driver = $match.Driver
                Name   = $d.FriendlyName
                Status = $d.Status
                Class  = $d.Class
                Id     = "VID_$vid & PID_$pidHex"
            }
        }
    }
}

# COM-порты (плата видна как COM только когда драйвер уже установлен)
$ports = @()
try {
    $ports = Get-CimInstance Win32_SerialPort | Select-Object DeviceID, Description, PNPDeviceID
} catch { }
if (-not $ports) {
    $ports = [System.IO.Ports.SerialPort]::GetPortNames() |
        ForEach-Object { [pscustomobject]@{ DeviceID = $_; Description = '(имя недоступно)'; PNPDeviceID = '' } }
}

if ($hits.Count -eq 0) {
    Write-Host 'Мост USB-UART не найден.' -ForegroundColor Yellow
    Write-Host ''
    Write-Host 'Что проверить по порядку:'
    Write-Host '  1. Кабель. Самая частая причина — кабель только для зарядки, без линий данных.'
    Write-Host '     Взять заведомо рабочий data-кабель и переткнуть.'
    Write-Host '  2. На плате должен гореть красный LED питания при подключении USB.'
    Write-Host '  3. Диспетчер устройств: если есть строка с жёлтым треугольником в'
    Write-Host '     "Другие устройства" — нажать по ней ПКМ → Свойства → Сведения →'
    Write-Host '     "ИД оборудования" и найти VID/PID в таблице SETUP.md, шаг 2.'
    Write-Host ''
} else {
    foreach ($h in $hits) {
        Write-Host ''
        Write-Host ("Найден мост: {0}  ({1})" -f $h.Chip, $h.Id) -ForegroundColor Green
        Write-Host ("  устройство : {0}" -f $h.Name)
        Write-Host ("  состояние  : {0}" -f $h.Status)
        if ($h.Class -eq 'Ports' -or $h.Status -eq 'OK') {
            Write-Host '  драйвер    : установлен' -ForegroundColor Green
        } else {
            Write-Host '  драйвер    : НЕ установлен' -ForegroundColor Yellow
            Write-Host ("               {0}" -f $h.Driver)
        }
    }
    Write-Host ''
}

Write-Host '=== COM-порты в системе ===' -ForegroundColor Cyan
if (-not $ports -or $ports.Count -eq 0) {
    Write-Host 'COM-портов нет.' -ForegroundColor Yellow
} else {
    foreach ($p in $ports) {
        $mark = ''
        if ($p.PNPDeviceID -match 'VID_(10C4|1A86|303A)') { $mark = '   <-- похоже, это ESP32' }
        Write-Host ("  {0}  {1}{2}" -f $p.DeviceID, $p.Description, $mark)
    }
}

# Порт платы: сначала по VID моста, иначе — единственный COM в системе
$espPort = ($ports | Where-Object { $_.PNPDeviceID -match 'VID_(10C4|1A86|303A)' } | Select-Object -First 1).DeviceID
if (-not $espPort -and $ports.Count -eq 1) { $espPort = $ports[0].DeviceID }

Write-Host ''
if ($espPort) {
    Write-Host ("ESP32 доступен на порту: {0}" -f $espPort) -ForegroundColor Green
    Write-Host ("Прошивка:  powershell -ExecutionPolicy Bypass -File tools\flash-usb.ps1 -Port {0}" -f $espPort)
    Write-Host ("Монитор :  arduino-cli monitor -p {0} -c baudrate=115200" -f $espPort)
    exit 0
} else {
    Write-Host 'COM-порт платы не определён — см. подсказки выше.' -ForegroundColor Yellow
    exit 1
}
