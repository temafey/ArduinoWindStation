﻿# _common.ps1 — общие функции для остальных скриптов (точками не запускается сам).

$script:ProjectRoot = Split-Path -Parent $PSScriptRoot
$script:SketchDir   = Join-Path $ProjectRoot 'esp32_wind_station'
$script:Fqbn        = 'esp32:esp32:esp32'

function Get-ArduinoCli {
    # arduino-cli может лежать в PATH (winget) или в %LOCALAPPDATA%\ArduinoCLI (zip)
    $cmd = Get-Command arduino-cli.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $candidates = @(
        "$env:LOCALAPPDATA\ArduinoCLI\arduino-cli.exe",
        "$env:ProgramFiles\Arduino CLI\arduino-cli.exe",
        "$env:LOCALAPPDATA\Microsoft\WinGet\Links\arduino-cli.exe"
    )
    foreach ($c in $candidates) { if (Test-Path $c) { return $c } }
    return $null
}

function Assert-ArduinoCli {
    $cli = Get-ArduinoCli
    if (-not $cli) {
        Write-Host 'arduino-cli не найден. Сначала выполнить шаг 3 из SETUP.md:' -ForegroundColor Red
        Write-Host '  powershell -ExecutionPolicy Bypass -File tools\setup-windows.ps1'
        exit 1
    }
    return $cli
}

function Get-Esp32CorePath {
    # Ядро ставится в %LOCALAPPDATA%\Arduino15\packages\esp32\hardware\esp32\<версия>
    $base = "$env:LOCALAPPDATA\Arduino15\packages\esp32\hardware\esp32"
    if (-not (Test-Path $base)) { return $null }
    return (Get-ChildItem $base -Directory | Sort-Object Name -Descending | Select-Object -First 1).FullName
}

function Get-CoreTool {
    param([Parameter(Mandatory)][string]$Name)   # espota.exe | esptool.exe
    $core = Get-Esp32CorePath
    if ($core) {
        $p = Join-Path $core "tools\$Name"
        if (Test-Path $p) { return $p }
    }
    $found = Get-ChildItem "$env:LOCALAPPDATA\Arduino15\packages\esp32\tools" -Recurse -Filter $Name -ErrorAction SilentlyContinue |
             Select-Object -First 1
    if ($found) { return $found.FullName }
    return $null
}

function Get-EspPort {
    # Порт по VID моста USB-UART; если мост не опознан, но COM ровно один — берём его
    $ports = @()
    try { $ports = Get-CimInstance Win32_SerialPort | Select-Object DeviceID, PNPDeviceID } catch { }
    $hit = $ports | Where-Object { $_.PNPDeviceID -match 'VID_(10C4|1A86|303A)' } | Select-Object -First 1
    if ($hit) { return $hit.DeviceID }
    $names = [System.IO.Ports.SerialPort]::GetPortNames()
    if ($names.Count -eq 1) { return $names[0] }
    return $null
}

function Get-BuildDir {
    return Join-Path $SketchDir 'build\esp32.esp32.esp32'
}
