﻿# flash-usb.ps1 — прошивка ESP32 по USB.
# Запуск:  powershell -ExecutionPolicy Bypass -File tools\flash-usb.ps1
#          powershell -ExecutionPolicy Bypass -File tools\flash-usb.ps1 -Port COM4
#          powershell -ExecutionPolicy Bypass -File tools\flash-usb.ps1 -Manual   # ручной вход в boot-режим

param(
    [string]$Port,       # COM-порт; по умолчанию определяется автоматически
    [switch]$Manual,     # esptool с --before no_reset: плату в boot-режим вводим кнопками
    [switch]$NoBuild     # не пересобирать, залить уже собранный бинарник
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot '_common.ps1')

$cli = Assert-ArduinoCli

if (-not $Port) {
    $Port = Get-EspPort
    if (-not $Port) {
        Write-Host 'COM-порт платы не определён.' -ForegroundColor Red
        Write-Host 'Запустить  powershell -ExecutionPolicy Bypass -File tools\find-esp32.ps1'
        Write-Host 'или указать порт явно:  -Port COM4'
        exit 1
    }
    Write-Host ("Порт определён автоматически: {0}" -f $Port) -ForegroundColor Green
}

# --- сборка ---------------------------------------------------------------
if (-not $NoBuild) {
    & (Join-Path $PSScriptRoot 'build.ps1')
    if ($LASTEXITCODE -ne 0) { exit 1 }
}

$buildDir = Get-BuildDir
$app      = Join-Path $buildDir 'esp32_wind_station.ino.bin'
if (-not (Test-Path $app)) {
    Write-Host "Нет собранного бинарника ($app). Убрать -NoBuild или выполнить tools\build.ps1." -ForegroundColor Red
    exit 1
}

# --- обычная заливка ------------------------------------------------------
if (-not $Manual) {
    Write-Host ''
    Write-Host ("=== Заливка на {0} ===" -f $Port) -ForegroundColor Cyan
    & $cli upload -p $Port --fqbn $Fqbn --input-dir $buildDir
    if ($LASTEXITCODE -eq 0) {
        Write-Host ''
        Write-Host 'Залито.' -ForegroundColor Green
        Write-Host ("Монитор: arduino-cli monitor -p {0} -c baudrate=115200  (нажать EN на плате)" -f $Port)
        exit 0
    }
    Write-Host ''
    Write-Host 'Заливка не прошла.' -ForegroundColor Yellow
    Write-Host 'Если в логе "Wrong boot mode detected (0x13)" или "Write timeout" — плата не вошла'
    Write-Host 'в режим загрузки сама. Повторить в ручном режиме:'
    Write-Host ("  powershell -ExecutionPolicy Bypass -File tools\flash-usb.ps1 -Port {0} -Manual -NoBuild" -f $Port)
    exit 1
}

# --- ручной режим: esptool --before no_reset ------------------------------
# arduino-cli тут не подходит: esptool через него сам дёргает DTR/RTS и отменяет
# ручной вход в download mode (на нашей макетке автосброс дополнительно ломает C1 1000 мкФ).
$esptool = Get-CoreTool 'esptool.exe'
if (-not $esptool) {
    Write-Host 'esptool.exe не найден в ядре esp32 — выполнить tools\setup-windows.ps1.' -ForegroundColor Red
    exit 1
}

$core       = Get-Esp32CorePath
$bootloader = Join-Path $buildDir 'esp32_wind_station.ino.bootloader.bin'
$partitions = Join-Path $buildDir 'esp32_wind_station.ino.partitions.bin'
$bootApp0   = Join-Path $core 'tools\partitions\boot_app0.bin'

foreach ($f in @($bootloader, $partitions, $bootApp0)) {
    if (-not (Test-Path $f)) {
        Write-Host "Не найден файл образа: $f" -ForegroundColor Red
        exit 1
    }
}

Write-Host ''
Write-Host '=== Ручной режим прошивки ===' -ForegroundColor Cyan
Write-Host 'На плате, ПЕРЕД тем как нажать Enter:'
Write-Host '  1. зажать и держать BOOT (она же IO0)'
Write-Host '  2. коротко нажать и отпустить EN (Reset)'
Write-Host '  3. BOOT продолжать держать'
Write-Host 'Затем нажать Enter здесь. BOOT отпустить, когда пойдёт "Writing at 0x...".'
Read-Host 'Enter для старта'

# esptool v5 переименовал команды и флаги на дефисы (write-flash / --before no-reset),
# в v4 и старше они через подчёркивание. Определяем версию и подставляем нужный набор.
$verLine = (& $esptool version 2>&1 | Select-Object -First 1) -join ''
$major = 5
if ($verLine -match 'v?(\d+)\.\d+') { $major = [int]$Matches[1] }

if ($major -ge 5) {
    $espArgs = @('--chip','esp32','--port',$Port,'--baud','460800','--before','no-reset','--after','hard-reset',
              'write-flash','--flash-mode','dio','--flash-freq','40m','--flash-size','detect')
} else {
    $espArgs = @('--chip','esp32','--port',$Port,'--baud','460800','--before','no_reset','--after','hard_reset',
              'write_flash','-z','--flash_mode','dio','--flash_freq','40m','--flash_size','detect')
}
$espArgs += @('0x1000',$bootloader,'0x8000',$partitions,'0xe000',$bootApp0,'0x10000',$app)

Write-Host ("esptool: {0} (v{1})" -f $esptool, $major)
& $esptool @espArgs

if ($LASTEXITCODE -eq 0) {
    Write-Host ''
    Write-Host 'Залито.' -ForegroundColor Green
    Write-Host ("Монитор: arduino-cli monitor -p {0} -c baudrate=115200  (нажать EN на плате)" -f $Port)
    Write-Host 'Ожидаемо: "=== Wind Station ===", затем IP или точка доступа WindStation-Setup.'
} else {
    Write-Host ''
    Write-Host 'Опять не вошла в режим загрузки. Повторить, отпуская BOOT позже —' -ForegroundColor Yellow
    Write-Host 'строго после появления "Writing at 0x..." в логе.'
    exit 1
}
