﻿# flash-ota.ps1 — прошивка станции по WiFi (OTA), USB не нужен.
# Запуск:  powershell -ExecutionPolicy Bypass -File tools\flash-ota.ps1 -Ip 192.168.1.223
#          ... -NoBuild        залить уже собранный бинарник
#          ... -AddFirewall    создать правило брандмауэра (нужен запуск от админа)

param(
    [Parameter(Mandatory)][string]$Ip,        # IP станции в локальной сети
    [int]$DevicePort = 3232,                  # порт OTA на плате
    [int]$LocalPort  = 45678,                 # локальный порт, к которому подключается плата
    [Parameter(Mandatory)][string]$Password,        # пароль OTA — спросить у автора прошивки, в комплекте его нет
    [switch]$NoBuild,
    [switch]$AddFirewall
)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot '_common.ps1')

# --- правило брандмауэра --------------------------------------------------
# espota поднимает СЛУШАЮЩИЙ порт, к которому подключается плата. Если входящие
# на этот порт режутся, получаем "No response from device" ещё до передачи данных.
$ruleName = "WindStation OTA $LocalPort"
$rule = Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue

if ($AddFirewall) {
    if ($rule) {
        Write-Host "Правило брандмауэра '$ruleName' уже есть." -ForegroundColor Green
    } else {
        $admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
                 ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        if (-not $admin) {
            Write-Host 'Для создания правила нужен PowerShell от имени администратора.' -ForegroundColor Red
            Write-Host 'Открыть админский PowerShell и выполнить:'
            Write-Host ("  New-NetFirewallRule -DisplayName '{0}' -Direction Inbound -Protocol TCP -LocalPort {1} -RemoteAddress {2} -Action Allow" -f $ruleName, $LocalPort, $Ip)
            exit 1
        }
        New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Protocol TCP `
            -LocalPort $LocalPort -RemoteAddress $Ip -Action Allow | Out-Null
        Write-Host "Правило '$ruleName' создано." -ForegroundColor Green
    }
} elseif (-not $rule) {
    Write-Host ''
    Write-Host "Правила брандмауэра для порта $LocalPort нет." -ForegroundColor Yellow
    Write-Host 'Без него OTA обычно падает с "No response from device". Создать:'
    Write-Host ("  powershell -ExecutionPolicy Bypass -File tools\flash-ota.ps1 -Ip {0} -AddFirewall   (от админа)" -f $Ip)
    Write-Host 'Продолжаю без правила — если сорвётся, начинать разбор отсюда.'
}

# --- станция на связи? ----------------------------------------------------
$before = $null
try {
    $before = Invoke-RestMethod -Uri "http://$Ip/api/data" -TimeoutSec 5
    Write-Host ("Станция отвечает: uptime={0} c, RSSI={1}" -f $before.uptime, $before.wifiRssi) -ForegroundColor Green
} catch {
    Write-Host "Станция по http://$Ip/api/data не отвечает — проверить IP и сеть." -ForegroundColor Yellow
    Write-Host 'Если IP неизвестен: посмотреть в веб-интерфейсе роутера или в Serial-мониторе после EN.'
}

# --- сборка ---------------------------------------------------------------
if (-not $NoBuild) {
    & (Join-Path $PSScriptRoot 'build.ps1')
    if ($LASTEXITCODE -ne 0) { exit 1 }
}

$bin = Join-Path (Get-BuildDir) 'esp32_wind_station.ino.bin'
if (-not (Test-Path $bin)) {
    Write-Host "Нет собранного бинарника ($bin) — выполнить tools\build.ps1." -ForegroundColor Red
    exit 1
}

$espota = Get-CoreTool 'espota.exe'
if (-not $espota) {
    Write-Host 'espota.exe не найден в ядре esp32 — выполнить tools\setup-windows.ps1.' -ForegroundColor Red
    exit 1
}

Write-Host ''
Write-Host ("=== OTA на {0}:{1} ===" -f $Ip, $DevicePort) -ForegroundColor Cyan
& $espota -i $Ip -p $DevicePort -P $LocalPort -a $Password -f $bin -r
$otaExit = $LASTEXITCODE

# Финальное "Unexpected response from device: '1024'" — косметика, не ошибка.
# Единственный надёжный признак успеха — СБРОС uptime в /api/data.
Write-Host ''
if ($otaExit -ne 0) {
    Write-Host ("espota вернул код {0} — сам по себе это ещё ничего не значит, проверяем по uptime." -f $otaExit) -ForegroundColor Yellow
}
Write-Host 'Проверяю uptime (успех = счётчик сбросился)...' -ForegroundColor Cyan
Start-Sleep -Seconds 12
$after = $null
for ($i = 1; $i -le 5; $i++) {
    try { $after = Invoke-RestMethod -Uri "http://$Ip/api/data" -TimeoutSec 5; break }
    catch { Start-Sleep -Seconds 5 }
}

if (-not $after) {
    Write-Host 'Станция не отвечает после заливки.' -ForegroundColor Yellow
    Write-Host 'Подождать полминуты и открыть http://' -NoNewline; Write-Host "$Ip/api/data"
    Write-Host 'Если тишина — перезагрузить плату по питанию и повторить.'
    exit 1
}

if ($before -and $after.uptime -ge $before.uptime) {
    Write-Host ("uptime НЕ сбросился ({0} -> {1}) — прошивка не применилась." -f $before.uptime, $after.uptime) -ForegroundColor Yellow
    Write-Host 'OTA бывает флаки: перезагрузить плату по питанию и повторить, до 3 попыток.'
    exit 1
}

Write-Host ("Готово. uptime={0} c — прошивка применилась." -f $after.uptime) -ForegroundColor Green
Write-Host ("Дашборд: http://{0}" -f $Ip)
exit 0
