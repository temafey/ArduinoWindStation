﻿# build.ps1 — компиляция прошивки.
# Запуск:  powershell -ExecutionPolicy Bypass -File tools\build.ps1
# Результат: esp32_wind_station\build\esp32.esp32.esp32\esp32_wind_station.ino.bin

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot '_common.ps1')

$cli = Assert-ArduinoCli

Write-Host ''
Write-Host '=== Компиляция esp32_wind_station ===' -ForegroundColor Cyan
Write-Host "  скетч: $SketchDir"
Write-Host "  плата: $Fqbn"
Write-Host ''

& $cli compile --fqbn $Fqbn --export-binaries $SketchDir
if ($LASTEXITCODE -ne 0) {
    Write-Host ''
    Write-Host 'Компиляция не прошла.' -ForegroundColor Red
    Write-Host 'Если жалуется на отсутствующее ядро — выполнить tools\setup-windows.ps1.'
    exit 1
}

$bin = Join-Path (Get-BuildDir) 'esp32_wind_station.ino.bin'
Write-Host ''
if (Test-Path $bin) {
    $kb = [math]::Round((Get-Item $bin).Length / 1KB)
    Write-Host ("Готово: {0}  ({1} КБ)" -f $bin, $kb) -ForegroundColor Green
    Write-Host 'Занятость флеша около 90% — это норма для текущей версии.'
    Write-Host ''
    Write-Host 'Дальше:'
    Write-Host '  по USB : powershell -ExecutionPolicy Bypass -File tools\flash-usb.ps1'
    Write-Host '  по WiFi: powershell -ExecutionPolicy Bypass -File tools\flash-ota.ps1 -Ip <IP станции>'
} else {
    Write-Host "Бинарник не найден по пути $bin — см. вывод компилятора выше." -ForegroundColor Red
    exit 1
}
